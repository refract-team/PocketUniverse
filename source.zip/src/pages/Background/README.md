We copy and paste over from server because we make some minor changes.

This is reallly annoying and we should figure out how this actually works.
